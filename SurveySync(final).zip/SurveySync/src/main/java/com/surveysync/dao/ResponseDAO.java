package com.surveysync.dao;

import com.surveysync.entity.Response;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ResponseDAO {
    private Connection connection;

    public ResponseDAO(Connection connection) {
        this.connection = connection;
    }

    public void submitResponse(Response response) throws SQLException {
        String query = "INSERT INTO Response (question_id, response_text, respondent_email) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, response.getQuestionId());
            stmt.setString(2, response.getResponseText());
            stmt.setString(3, response.getRespondentEmail());
            stmt.executeUpdate();
        }
    }
}
