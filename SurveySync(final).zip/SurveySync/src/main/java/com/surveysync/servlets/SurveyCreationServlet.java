package com.surveysync.servlets;

import com.surveysync.dao.SurveyDAO;
import com.surveysync.entity.Survey;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

@WebServlet("/createSurvey")
public class SurveyCreationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String description = request.getParameter("description");

        Survey survey = new Survey();
        survey.setTitle(title);
        survey.setDescription(description);

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
            SurveyDAO surveyDAO = new SurveyDAO(connection);
            surveyDAO.createSurvey(survey);
            response.sendRedirect("surveyCreated.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
