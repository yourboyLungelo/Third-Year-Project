package com.surveysync.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Map;

@WebServlet("/downloadCsv")
public class DownloadCsvServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String surveyIdParam = request.getParameter("surveyId");
        int surveyId;

        try {
            surveyId = Integer.parseInt(surveyIdParam);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid survey ID format.");
            return;
        }

        SurveyService surveyService = new SurveyService();
        Map<String, Integer> analyticsData;

        try {
            analyticsData = surveyService.getSurveyAnalytics(surveyId);
        } catch (SQLException e) {
            throw new ServletException("Error retrieving survey analytics data.", e);
        }

        if (analyticsData == null || analyticsData.isEmpty()) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "No analytics data available.");
            return;
        }

        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=\"survey_analytics.csv\"");

        PrintWriter writer = response.getWriter();
        writer.println("Question,Response Count");

        for (Map.Entry<String, Integer> entry : analyticsData.entrySet()) {
            writer.printf("\"%s\",%d%n", entry.getKey().replace("\"", "\"\""), entry.getValue());
        }

        writer.flush();
        writer.close();
    }
}
