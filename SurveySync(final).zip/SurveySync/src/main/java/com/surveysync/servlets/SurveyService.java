package com.surveysync.servlets;

import java.sql.*;
import java.util.*;





public class SurveyService {

    private String jdbcUrl = "jdbc:mysql://localhost:3306/test"; 
    private String jdbcUser = "root"; 
    private String jdbcPassword = "";  

    public SurveyService() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Method to create a survey, store questions, and answers
    public void createSurvey(String surveyTitle, String[] questions) throws SQLException {
        Connection conn = null;
        PreparedStatement surveyStmt = null;
        PreparedStatement questionStmt = null;
        PreparedStatement answerStmt = null;

        try {
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);
            conn.setAutoCommit(false);  // Start transaction

            // Insert survey into the Survey table
            String surveyQuery = "INSERT INTO Survey (title) VALUES (?)";
            surveyStmt = conn.prepareStatement(surveyQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            surveyStmt.setString(1, surveyTitle);
            surveyStmt.executeUpdate();

            // Get the generated survey ID
            ResultSet surveyKeys = surveyStmt.getGeneratedKeys();
            surveyKeys.next();
            int surveyId = surveyKeys.getInt(1);

            // Insert each question and associated answers
            String questionQuery = "INSERT INTO Question (survey_id, question_text) VALUES (?, ?)";
            String answerQuery = "INSERT INTO Answer (question_id, answer_text) VALUES (?, ?)";

            for (int i = 0; i < questions.length; i++) {
                // Insert question
                questionStmt = conn.prepareStatement(questionQuery, PreparedStatement.RETURN_GENERATED_KEYS);
                questionStmt.setInt(1, surveyId);
                questionStmt.setString(2, questions[i]);
                questionStmt.executeUpdate();

                // Get the generated question ID
                ResultSet questionKeys = questionStmt.getGeneratedKeys();
                questionKeys.next();
                int questionId = questionKeys.getInt(1);

               
            }

            conn.commit(); 

        } catch (SQLException e) {
            if (conn != null) conn.rollback();  
            throw new SQLException(e);
        } finally {
            if (surveyStmt != null) surveyStmt.close();
            if (questionStmt != null) questionStmt.close();
            if (answerStmt != null) answerStmt.close();
            if (conn != null) conn.close();
        }
    }

    // Method to get all available surveys for users to respond to
    public List<Survey> getAllSurveys() throws SQLException {
        List<Survey> surveys = new ArrayList<Survey>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);

            String query = "SELECT * FROM Survey";
            stmt = conn.prepareStatement(query);
            rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                surveys.add(new Survey(id, title));
            }

        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }

        return surveys;
    }
 // Method to submit text responses to a survey
    public void submitTextResponses(int surveyId, Map<Integer, String> responses) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);
            conn.setAutoCommit(false);  // Start transaction

            String query = "INSERT INTO response (survey_id, question_id, response_text) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(query);

            for (Map.Entry<Integer, String> entry : responses.entrySet()) {
                int questionId = entry.getKey();
                String responseText = entry.getValue();

                stmt.setInt(1, surveyId);
                stmt.setInt(2, questionId);
                stmt.setString(3, responseText);
                stmt.addBatch();  // Add to batch for bulk insertion
            }

            stmt.executeBatch();
            conn.commit();  // Commit transaction

        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw new SQLException(e);
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
    }
    

    // Method to get survey questions by survey ID
    public List<Question> getSurveyQuestions(int surveyId) throws SQLException {
        List<Question> questions = new ArrayList<Question>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);

            String query = "SELECT id, question_text FROM Question WHERE survey_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, surveyId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                int questionId = rs.getInt("id");
                String questionText = rs.getString("question_text");
                List<Answer> answers = getAnswersForQuestion(questionId);
                questions.add(new Question(questionId, questionText, answers));
            }

        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }

        return questions;
    }

    // Method to get answers for a question
    private List<Answer> getAnswersForQuestion(int questionId) throws SQLException {
        List<Answer> answers = new ArrayList<Answer>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);

            String query = "SELECT id, answer_text FROM Answer WHERE question_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, questionId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                int answerId = rs.getInt("id");
                String answerText = rs.getString("answer_text");
                answers.add(new Answer(answerId, answerText));
            }

        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }

        return answers;
    }

    // Method to submit responses to a survey
    public void submitResponses(int surveyId, Map<Integer, Integer> responses) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);
            conn.setAutoCommit(false);  // Start transaction

            String query = "INSERT INTO Response (survey_id, question_id, answer_id) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(query);

            for (Map.Entry<Integer, Integer> entry : responses.entrySet()) {
                int questionId = entry.getKey();
                int answerId = entry.getValue();

                stmt.setInt(1, surveyId);
                stmt.setInt(2, questionId);
                stmt.setInt(3, answerId);
                stmt.addBatch();  // Add to batch for bulk insertion
            }

            stmt.executeBatch();
            conn.commit();  // Commit transaction

        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw new SQLException(e);
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
    }

    // Method to retrieve analytics data (e.g., response count per question)
    public Map<String, Integer> getSurveyAnalytics(int surveyId) throws SQLException {
        Map<String, Integer> analyticsData = new HashMap<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);

            String query = "SELECT q.question_text, COUNT(r.answer_id) AS response_count " +
                    "FROM Question q " +
                    "LEFT JOIN Response r ON q.id = r.question_id " +
                    "WHERE q.survey_id = ? " +
                    "GROUP BY q.id, q.question_text";

            stmt = conn.prepareStatement(query);
            stmt.setInt(1, surveyId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                String questionText = rs.getString("question_text");
                int responseCount = rs.getInt("response_count");
                analyticsData.put(questionText, responseCount);
            }

        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }

        return analyticsData;
    }
    
    public Survey getSurveyById(int surveyId) throws SQLException {
        Survey survey = null;
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);
            String query = "SELECT title FROM Survey WHERE id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, surveyId);
            rs = stmt.executeQuery();

            if (rs.next()) {
                String title = rs.getString("title");
                survey = new Survey(surveyId, title);
            }
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }

        return survey;
    }

    // Inner class to represent Survey
    public class Survey {
        private int id;
        private String title;

        public Survey(int id, String title) {
            this.id = id;
            this.title = title;
        }

        public int getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }
    }

    // Inner class to represent Question
    public class Question {
        private int id;
        private String questionText;
        private List<Answer> answers;

        public Question(int id, String questionText, List<Answer> answers) {
            this.id = id;
            this.questionText = questionText;
            this.answers = answers;
        }

        public int getId() {
            return id;
        }

        public String getQuestionText() {
            return questionText;
        }

        public List<Answer> getAnswers() {
            return answers;
        }
    }

    // Inner class to represent Answer
    public class Answer {
        private int id;
        private String answerText;

        public Answer(int id, String answerText) {
            this.id = id;
            this.answerText = answerText;
        }

        public int getId() {
            return id;
        }

        public String getAnswerText() {
            return answerText;
        }
    }
}
