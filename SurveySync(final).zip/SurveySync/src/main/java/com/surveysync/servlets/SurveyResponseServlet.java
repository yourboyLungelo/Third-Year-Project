package com.surveysync.servlets;

import com.surveysync.dao.ResponseDAO;
import com.surveysync.entity.Response;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

@WebServlet("/submitResponse")
public class SurveyResponseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int questionId = Integer.parseInt(request.getParameter("questionId"));
        String responseText = request.getParameter("responseText");
        String email = request.getParameter("email");

        Response surveyResponse = new Response(questionId, questionId, email, email);
        surveyResponse.setQuestionId(questionId);
        surveyResponse.setResponseText(responseText);
        surveyResponse.setRespondentEmail(email);

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
            ResponseDAO responseDAO = new ResponseDAO(connection);
            responseDAO.submitResponse(surveyResponse);
            response.sendRedirect("thankYou.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
