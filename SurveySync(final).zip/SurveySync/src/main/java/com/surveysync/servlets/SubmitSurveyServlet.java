package com.surveysync.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/SubmitSurveyServlet")
public class SubmitSurveyServlet extends HttpServlet {

    private SurveyService surveyService;

    @Override
    public void init() throws ServletException {
        
        surveyService = new SurveyService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String surveyTitle = request.getParameter("surveyTitle");
        String[] questions = request.getParameterValues("questions[]");

       

        try {
            surveyService.createSurvey(surveyTitle, questions);
            response.sendRedirect("surveyCreated.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
