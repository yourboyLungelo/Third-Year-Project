package com.surveysync.servlets;



import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class SurveyAnalyticsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        SurveyService surveyService = new SurveyService();
        List<SurveyService.Survey> surveys = null;

        try {
            surveys = surveyService.getAllSurveys();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("surveys", surveys);
        RequestDispatcher dispatcher = request.getRequestDispatcher("surveyAnalytics.jsp");
        dispatcher.forward(request, response);
    }
}
