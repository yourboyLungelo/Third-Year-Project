package com.surveysync.dao;

import com.surveysync.entity.Question;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QuestionDAO {
    private Connection connection;

    public QuestionDAO(Connection connection) {
        this.connection = connection;
    }

    public void addQuestion(Question question) throws SQLException {
        String query = "INSERT INTO Question (survey_id, question_text, question_type) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, question.getSurveyId());
            stmt.setString(2, question.getQuestionText());
            stmt.setString(3, question.getQuestionType());
            stmt.executeUpdate();
        }
    }

    public List<Question> getQuestionsBySurveyId(int surveyId) throws SQLException {
        List<Question> questions = new ArrayList<>();
        String query = "SELECT * FROM Question WHERE survey_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, surveyId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Question question = new Question();
                    question.setId(rs.getInt("id"));
                    question.setSurveyId(rs.getInt("survey_id"));
                    question.setQuestionText(rs.getString("question_text"));
                    question.setQuestionType(rs.getString("question_type"));
                    questions.add(question);
                }
            }
        }
        return questions;
    }
}
