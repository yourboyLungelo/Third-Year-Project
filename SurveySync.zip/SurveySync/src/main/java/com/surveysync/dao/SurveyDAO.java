package com.surveysync.dao;

import com.surveysync.entity.Survey;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SurveyDAO {
    private Connection connection;

    public SurveyDAO(Connection connection) {
        this.connection = connection;
    }

    public void createSurvey(Survey survey) throws SQLException {
        String query = "INSERT INTO Survey (title, description) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, survey.getTitle());
            stmt.setString(2, survey.getDescription());
            stmt.executeUpdate();
        }
    }

    public List<Survey> getAllSurveys() throws SQLException {
        List<Survey> surveys = new ArrayList<>();
        String query = "SELECT * FROM Survey";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Survey survey = new Survey();
                survey.setId(rs.getInt("id"));
                survey.setTitle(rs.getString("title"));
                survey.setDescription(rs.getString("description"));
                surveys.add(survey);
            }
        }
        return surveys;
    }
}
