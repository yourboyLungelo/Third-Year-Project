package com.surveysync.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/viewSurvey")
public class ViewSurveysServlet extends HttpServlet {

    private SurveyService surveyService = new SurveyService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Fetch surveys with response count
            List<SurveyService.Survey> surveys = surveyService.getSurveysWithResponseCount();

            // Set the surveys as an attribute to pass it to the JSP
            request.setAttribute("surveys", surveys);

            // Forward request to the JSP page
            request.getRequestDispatcher("/viewSurvey.jsp").forward(request, response);

        } catch (SQLException e) {
            throw new ServletException("Unable to retrieve surveys", e);
        }
    }
}
