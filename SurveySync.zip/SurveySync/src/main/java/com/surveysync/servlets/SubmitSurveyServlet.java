package com.surveysync.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/SubmitSurveyServlet")
public class SubmitSurveyServlet extends HttpServlet {

    private SurveyService surveyService;

    @Override
    public void init() throws ServletException {
        // Initialize SurveyService
        surveyService = new SurveyService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String surveyTitle = request.getParameter("surveyTitle");
        String[] questions = request.getParameterValues("questions[]");

        // Assuming answers are in a 2D array format (each question has multiple answers)
        String[][] answers = {
            request.getParameterValues("answers1[]"),
            request.getParameterValues("answers2[]"),
            // Add more as needed
        };

        try {
            surveyService.createSurvey(surveyTitle, questions, answers);
            response.sendRedirect("surveyCreated.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
