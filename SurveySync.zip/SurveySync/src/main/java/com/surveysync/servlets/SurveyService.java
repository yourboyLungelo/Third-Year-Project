package com.surveysync.servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SurveyService {

    private String jdbcUrl = "jdbc:mysql://localhost:3306/test";  // Update the database name
    private String jdbcUser = "root";  // Update with your DB user
    private String jdbcPassword = "";  // Update with your DB password

    public SurveyService() {
        try {
            // Registering MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Method to create the survey, store questions, and answers
    public void createSurvey(String surveyTitle, String[] questions, String[][] answers) throws SQLException {
        Connection conn = null;
        PreparedStatement surveyStmt = null;
        PreparedStatement questionStmt = null;
        PreparedStatement answerStmt = null;

        try {
            // Create a connection using DriverManager
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);
            conn.setAutoCommit(false);  // Start transaction

            // Insert survey into the Survey table
            String surveyQuery = "INSERT INTO Survey (title) VALUES (?)";
            surveyStmt = conn.prepareStatement(surveyQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            surveyStmt.setString(1, surveyTitle);
            surveyStmt.executeUpdate();

            // Get generated survey ID
            ResultSet surveyKeys = surveyStmt.getGeneratedKeys();
            surveyKeys.next();
            int surveyId = surveyKeys.getInt(1);

            // Insert each question and associated answers
            String questionQuery = "INSERT INTO Question (survey_id, question_text) VALUES (?, ?)";
            String answerQuery = "INSERT INTO Answer (question_id, answer_text) VALUES (?, ?)";

            for (int i = 0; i < questions.length; i++) {
                // Insert question
                questionStmt = conn.prepareStatement(questionQuery, PreparedStatement.RETURN_GENERATED_KEYS);
                questionStmt.setInt(1, surveyId);
                questionStmt.setString(2, questions[i]);
                questionStmt.executeUpdate();

                // Get generated question ID
                ResultSet questionKeys = questionStmt.getGeneratedKeys();
                questionKeys.next();
                int questionId = questionKeys.getInt(1);

                // Insert answers for this question, check if answers[i] is null
                if (answers[i] != null) {
                    for (String answerText : answers[i]) {
                        if (answerText != null && !answerText.isEmpty()) {
                            answerStmt = conn.prepareStatement(answerQuery);
                            answerStmt.setInt(1, questionId);
                            answerStmt.setString(2, answerText);
                            answerStmt.executeUpdate();
                        }
                    }
                }
            }

            conn.commit();  // Commit transaction

        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();  // Rollback transaction in case of an error
            }
            throw new SQLException(e);
        } finally {
            if (surveyStmt != null) surveyStmt.close();
            if (questionStmt != null) questionStmt.close();
            if (answerStmt != null) answerStmt.close();
            if (conn != null) conn.close();
        }
    }

    // Method to get surveys with their response counts
    public List<Survey> getSurveysWithResponseCount() throws SQLException {
        List<Survey> surveys = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);

            // SQL query to get surveys and their response counts
            String query = "SELECT s.id, s.title, COUNT(r.id) AS responseCount " +
                           "FROM Survey" +
                           "LEFT JOIN Response r ON s.id = r.survey_id " +
                           "GROUP BY s.id, s.title";

            stmt = conn.prepareStatement(query);
            rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                int responseCount = rs.getInt("responseCount");

                surveys.add(new Survey(id, title, responseCount));
            }

        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }

        return surveys;
    }

    // Inner class to hold Survey details
    public class Survey {
        private int id;
        private String title;
        private int responseCount;

        public Survey(int id, String title, int responseCount) {
            this.id = id;
            this.title = title;
            this.responseCount = responseCount;
        }

        public int getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }

        public int getResponseCount() {
            return responseCount;
        }
    }
}
